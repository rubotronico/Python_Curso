from setuptools import setup

setup(
	name="paquete",
	version="0.1",
	desctiption="Este es un paquete de ejemplo",
	author="Rubén González",
	author_email="rubotron2.0@gmail.com",
	url="http://blablabla.com",
	scripts=[],
	packages=["paquete","paquete.adios","paquete.hola"] 
)